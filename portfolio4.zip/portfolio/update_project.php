<?php
include 'db_connection.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = connectDatabase();
    
    if (isset($_POST['update'])) {
        $projectId = $_POST['update'];
        $title = $_POST['title'];
        $description = $_POST['description'];
        $imagePath = $_POST['image_path']; 

        
        if (!empty($_FILES['new_image']['name'])) {
            $newImagePath = 'uploads/' . $_FILES['new_image']['name'];
            move_uploaded_file($_FILES['new_image']['tmp_name'], $newImagePath);
            $imagePath = $newImagePath; 
        }

        $sql = "UPDATE projects SET title = ?, description = ?, image_path = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $title, $description, $imagePath, $projectId);

        if ($stmt->execute()) {
            header("Location: crud_operations.php"); 
        } else {
            echo "Error updating project: " . $conn->error;
        }

        $stmt->close();
        $conn->close();
    }
}
?>
